---
name: squeditor-preferences
description: >
  Use this skill to understand the user's specific coding preferences, design patterns, 
  and structural choices within the Squeditor workspace. Read this whenever generating 
  new components or sections to ensure alignment with the established project style.
---

# Squeditor Project Specific Preferences

Based on manual refinements made to the `hero-split` section and layout files, always adhere to the following patterns when building or modifying Squeditor templates:

## 1. DOM Structure & Naming Conventions
- **BEM Naming**: Use BEM-style modifiers for structural classes. Example: use `sq-hero--split` instead of `sq-hero-split`, and `sq-hero--inner` for inner wrappers.
- **Container Layout**: Avoid wrapping entire hero sections inside generic `sq-card` containers with background colors unless specifically asked. Instead, prefer invisible layout constraints like `max-w-7xl mx-auto lg:px-6 flex items-center justify-between`.
- **Decoupled Headers**: Do not inject `header` and `nav` template parts *inside* hero section files. Keep the hero section purely focused on hero content, allowing the global layout or page template to handle the header.

## 2. Animation Patterns (GSAP)
- **Staggers on Parents**: When animating a list of elements (like floating cards or lists), apply the `data-gsap` attribute with the `stagger` property **on the parent container**, rather than dynamically generating iterating delays on each child element. 
  - *Example Pattern*: `<div data-gsap="from: {opacity: 0, x: 30}; stagger: 0.15; delay: 0.3"> <!-- children --> </div>`

## 3. Styling & Tailwind Usage
- **Custom Utility Classes**: ALWAYS prefer the project's custom structural utility classes over raw Tailwind when dealing with colors. Use `text-muted` instead of `text-zinc-500`. Use `bg-secondary` instead of explicitly stating `bg-blue-600`.
- **Predefined SCSS over Tailwind**: ALWAYS analyze the project's existing SCSS before adding layout or text coloring via Tailwind. We have predefined global and theme-level classes for texts, backgrounds, and layout elements. Do not spam raw Tailwind color utilities (e.g., `text-blue-500` or `bg-gray-100`) if a semantic SCSS class already exists or should be mapped via CSS variables.
- **Button Utilities**: When styling buttons, utilize base classes like `btn btn-secondary` and apply overrides using `!important` Tailwind utilities (e.g., `!rounded-full !px-8 !py-4 !text-base !shadow-lg`) instead of creating entirely new custom classes.
- **Image Containers**: When defining image heights in grid columns, use fixed responsive heights (e.g., `h-[400px] md:h-[700px]`) on the container relative wrapper rather than relying solely on `min-h`.
- **Avatar Stacking**: Do not apply borders directly to `<img>` tags for overlapping avatars. Instead, wrap the `<img>` in a structure like `<div class="rounded-full border-[3px] overflow-hidden border-white dark:border-zinc-900">` and scale the image inside to `w-full h-full`.

## 4. Dark Mode Compliance
- **Never Hardcode Heading Colors**: Headings in this project are *already* configured to automatically respond to dark mode (via base SCSS or generic globals). **DO NOT** add explicit `text-zinc-900` or `text-black` utilities to headings.
- **Dark Selectors**: Actively utilize Tailwind's `dark:` modifier for backgrounds, borders, and overlays (e.g., `dark:bg-opacity-5`, `dark:border-zinc-900`, `dark:bg-zinc-700`).

## 5. Assets & Theming
- **Icons**: Do not rely on inline SVGs out of the box. Use the custom icon font system: `<i class="sq-icon sq-icon-[icon-name]"></i>`.
- **Colors**: Note that `--sq-color-primary` has been redefined to a dark theme tone (`#1c2020`). `--sq-color-secondary` is `#478fd2`. Highlights (like `.sq-highlight`) lean towards fuchsia-to-blue gradients rather than emerald.
- **Transitions**: The page transition overlay is explicitly hidden by default (`hidden` class) in the layout, likely to prevent annoyance during rapid development.
