---
name: gsap
description: >
  Use this skill when adding any animation to a Squeditor template, when writing
  data-gsap, data-gsap-split, or data-gsap-scroll attributes on HTML elements,
  when configuring gsap-init.js, when ScrollTrigger or SplitText behavior needs
  to be set up or debugged, or when scroll-driven animations, text reveals,
  pinning, parallax, or stagger effects are needed. Always read this skill before
  writing any animation-related code or attributes in a PHP template file.
---

# GSAP Skill — Squeditor

## Three Attributes, Three Use Cases

  data-gsap          Standard animations: fade, slide, stagger, scroll reveal
  data-gsap-split    Text reveal: split by chars, words, or lines via SplitText
  data-gsap-scroll   Advanced scroll: pin sections, scrub, parallax

Full schema for all three attributes: squeditor-gsap-integration.txt Section 7

## data-gsap Quick Reference

  <div data-gsap="from: {y: 40, opacity: 0}; duration: 0.75; ease: power2.out; scroll: true">

  Keys: from (required), duration, ease, delay, stagger, scroll, start, timeline

## data-gsap-split Quick Reference

  <h2 data-gsap-split="type: words; from: {y: 60, opacity: 0}; stagger: 0.06; scroll: true">

  Keys: type (chars|words|lines), from, stagger, duration, ease, scroll, start
  NEVER use on elements with child HTML tags. Plain text headings only.

## data-gsap-scroll Quick Reference

  <section data-gsap-scroll="pin: true; start: top top; end: +=600">
    <div data-gsap="from: {opacity: 0}; scroll: true">...</div>
  </section>

  Keys: scrub, pin, start, end
  ALWAYS pair with a data-gsap child. Scroll controls trigger. GSAP controls animation.

## Critical Rules

  1. Never animate UIKit3 roots: uk-modal, uk-offcanvas, uk-dropdown, uk-accordion
  2. Never apply data-gsap-split to elements with child HTML tags
  3. data-gsap-scroll always needs a data-gsap child element
  4. markers: false always in production
  5. gsap-init.js is imported by main.js — Vite bundles it, no extra config needed

## GSAP + UIKit3 Safe Zones

  SAFE:    Content inside uk-modal .uk-modal-body
  SAFE:    .sq-hero, .sq-card, .sq-section wrapper elements
  UNSAFE:  [uk-modal], [uk-offcanvas], [uk-sticky] root elements
  UNSAFE:  [uk-dropdown], [uk-accordion] root elements

## Easing Quick Reference

  power2.out    Smooth deceleration — default, works for most elements
  power3.out    Stronger deceleration — good for large movements
  expo.out      Very sharp then slow — dramatic hero animations
  back.out      Slight overshoot — good for chars and icon animations
  none          Linear — use only for scrub-based scroll animations

## Advanced Modules (data-sq-* attributes)

Eight advanced modules live in `src/assets/js/gsap-modules/`.
They load automatically via `gsap-advanced.js` only when their
trigger attribute is found on the page. Zero JS required per project.

| Attribute | Element | PHP Component |
|---|---|---|
| `data-sq-cursor` | `<body>` | set `$enable_cursor = true` in page file |
| `data-sq-preview` | `<ul>` | `get_component('preview-list', [...])` |
| `data-sq-tilt` | any element | add directly to any element |
| `data-sq-marquee` | div wrapper | `get_component('marquee', [...])` |
| `data-sq-panels` | section wrapper | `get_component('pinned-panels', [...])` |
| `data-sq-loop-panels` | section wrapper | add directly to wrapper |
| `data-sq-mask` | h1-h4, p | add directly to text element |
| `data-sq-swipe` | section wrapper | `get_component('swipe-slider', [...])` |

## Advanced Module Options

### data-sq-cursor
size, color, blend (CSS mix-blend-mode), scale-on-hover

### data-sq-tilt
max (degrees), scale, speed (ms)

### data-sq-marquee
speed (px/s), gap (px), direction (left/right)

### data-sq-panels
rounded (bool)

### data-sq-mask
type (lines/words), duration, stagger, ease, scroll (bool), start

### data-sq-swipe
duration, ease, show-nav (bool), show-dots (bool)

## Never apply data-sq-cursor and UIKit3 Offcanvas together.
## Never apply data-sq-swipe and UIKit3 Slider to the same wrapper.
## Never apply data-sq-mask to elements with child HTML tags.
## Never apply data-sq-tilt to UIKit3 Sticky elements.
