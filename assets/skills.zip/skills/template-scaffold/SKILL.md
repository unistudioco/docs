---
name: template-scaffold
description: >
  Use this skill when creating a new template project alongside the squeditor/ framework,
  when running scaffold.js, or when setting up the squeditor/project-template/ starter.
  Covers what scaffold.js must do, what project-template/ must contain, what to customize
  after scaffolding, and what must never be copied from squeditor/ into a template.
---

# Template Scaffold Skill

## Scaffold Command
```bash
# Run from workspace root
node squeditor/scripts/scaffold.js my-template-name
```

This creates `../my-template-name/` as a sibling of `squeditor/` — NOT inside it.

## What scaffold.js Must Do

1. Copy `squeditor/project-template/` → `../[template-name]/`
2. Replace `"my-project-name"` in `package.json` with the actual template name
3. Set `config.framework: '../squeditor'` in `squeditor.config.js`
4. Run `npm install` inside the new template folder
5. Print: "✅ Template [name] created. cd ../[name] && npm run dev to start."

## project-template/ Contents (inside squeditor/)
squeditor/project-template/
├── squeditor.config.js     ← template — agent fills in name + components
├── tailwind.config.js
├── vite.config.js
├── package.json
└── src/
├── config/site-config.php
├── data/team.php, blog.php, portfolio.php
├── assets/scss/ (all 6 layers + themes/)
├── assets/js/main.js
├── assets/static/ (placeholder images, fonts)
├── template-parts/ (header, footer, nav, mega-menu, breadcrumbs, page-title-bar)
├── components/ (all 10 UIKit3 components with demo mode)
├── sections/ (all section variants)
├── page-templates/ (base, home, inner-page, landing, 404)
├── pages/ (index, about, services, contact — with frontmatter)
└── style-guide.php

## What to Customize After Scaffolding

1. `squeditor.config.js` — set `name`, choose `components`, set `activeTheme`, set `dist.zipName`
2. `src/config/site-config.php` — set real site name, nav links, logo path, contact info
3. `src/assets/scss/themes/_theme.scss` — brand colors, fonts
4. `tailwind.config.js` — extend colors to match theme tokens if needed
5. Page content in `src/pages/`

## What Never Goes Inside squeditor/

- No client-specific images, fonts, or content
- No page files or section content
- No site-config data
- No `dist/` output
- The ONLY template-related file in squeditor/ is `project-template/` (the starter scaffold)