---
name: debugging
description: >
  Use this skill when anything in a Squeditor project is broken, not rendering, missing
  from output, or throwing errors. Covers the 5 most common failure modes with exact
  diagnosis steps and fixes: UIKit JS not initializing, Tailwind not purging PHP classes,
  snapshot producing empty HTML, assets missing from ZIP, and theme SCSS not swapping.
  Read this before giving up or rewriting working code.
---

# Debugging Skill

## Failure 1 — UIKit JS Components Not Initializing

**Symptoms:** Modal doesn't open, accordion doesn't expand, tabs don't switch.

**Diagnosis:**
1. Open browser console — look for `UIkit is not defined` or `Cannot read properties of undefined`
2. Check `dist/assets/js/uikit-components.js` exists and is non-empty
3. Check `uikit-core.js` is the FIRST content in the file
4. Check the `uk-` attribute matches exactly what UIKit3 expects (e.g. `uk-modal` not `data-uk-modal`)

**Fix:** Re-run `npm run build:css`. If still failing, check `uikit-manifest.json` paths
by running `node -e "require('fs').existsSync('node_modules/uikit/dist/js/uikit-core.js') && console.log('OK')"`.

---

## Failure 2 — Tailwind Not Purging / Classes Missing from CSS

**Symptoms:** Tailwind utilities used in PHP files don't appear in `tailwind.css`.

**Diagnosis:** Check `tailwind.config.js` content array:
```js
content: ['./src/**/*.php', './src/**/*.html']
```
The glob MUST include `*.php` — Tailwind won't scan PHP files otherwise.

**Fix:** Add `./src/**/*.php` to content array. Re-run `vite build`.

---

## Failure 3 — Snapshot Produces Empty or Incomplete HTML

**Symptoms:** `dist/` HTML files are empty, missing content, or missing navigation.

**Diagnosis options:**
- PHP server wasn't ready — increase the `setTimeout` delay in `snapshot.js` from 1500 to 3000ms
- PHP error in a template — run `php -S localhost:3000 -t src` manually and visit each page
- `SRC_PATH` not resolving — check `base.php` defines it correctly as `__DIR__ . '/..`
- Page not in `config.snapshot.pages` — add it

**Fix:** Test each page manually with PHP server before running snapshot.

---

## Failure 4 — Images or Fonts Missing from dist/ and ZIP

**Symptoms:** Images show in dev but not in `dist/`, broken image icons in ZIP.

**Diagnosis:** Check `vite.config.js` has `publicDir` set:
```js
publicDir: path.resolve(__dirname, 'src/assets/static')
```
Check the files are actually in `src/assets/static/images/` not `src/assets/images/`.

**Fix:** Add `publicDir` to vite.config.js. Move images to `src/assets/static/images/`.
Re-run `npm run build:css` (Vite build stage copies the files).

---

## Failure 5 — Theme SCSS Not Swapping

**Symptoms:** Active theme colors not applied, wrong theme loads in dist.

**Diagnosis:** Check `main.scss` has the anchor comment on the line ABOVE the theme import:
```scss
// auto-replaced by build-components.js — DO NOT edit manually
@import 'themes/agency';
```
Check `config.activeTheme` in `squeditor.config.js` matches a key in `config.themes`.

**Fix:** Restore the anchor comment if it was edited. Re-run `npm run build:css`.

---

## General Debug Sequence

1. Read the error message fully before acting
2. Identify which build stage failed (css / snap / zip)
3. Run that stage in isolation: `npm run build:css`, `npm run build:snap`, `npm run build:zip`
4. Check the relevant skill for that stage
5. If a PHP page is blank — test it directly at `http://localhost:3000/page.php`
6. If a file is missing from dist — check where Vite / snapshot should have created it
7. Never rewrite a working script to fix a path issue — fix the path