---
name: squeditor
description: >
  Master orientation skill for the Squeditor framework. Read this FIRST before
  doing anything else in a Squeditor project — before creating files, running builds,
  writing PHP, or touching SCSS. This skill explains the global vs local scope model,
  path resolution rules, class prefix conventions, and which sub-skill to read next
  for any given task. If you are working on anything related to Squeditor, antigravity
  framework, PHP templating, UIKit3 components, Tailwind builds, or static HTML
  generation — start here.
---

# Squeditor Master Skill

## Mental Model — Global vs Local Scope

[workspace-root]/
├── squeditor/        ← GLOBAL — framework core. NEVER add template-specific files here.
├── showcase/         ← LOCAL — template project, sibling of squeditor/
├── lexend/           ← LOCAL — template project, sibling of squeditor/
└── flowave/          ← LOCAL — template project, sibling of squeditor/

**Rule:** `squeditor/` contains zero template content. Templates contain zero framework logic.
Templates reference the framework only via `config.framework: '../squeditor'` in their config.

## Path Resolution Rule (Critical)

Every script inside `squeditor/scripts/` must resolve the framework root like this:
```js
const config   = require(path.join(projectRoot, 'squeditor.config.js'));
const fwRoot   = path.resolve(projectRoot, config.framework); // → ../squeditor
const manifest = require(path.join(fwRoot, 'uikit-manifest.json'));
```

`projectRoot` is always `process.cwd()` — the template folder the agent runs `npm` from.
NEVER hardcode `../squeditor` directly in scripts. Always go through `config.framework`.

## Class Prefix Convention

All custom Squeditor classes use the `sq-` prefix: `sq-card`, `sq-hero`, `sq--header`.
UIKit3 classes keep their `uk-` prefix. Tailwind utilities have no prefix.
Never mix or rename these.

## Config File Name

Each template's config is `squeditor.config.js` at the template root.
The framework never has its own config — it is configured by the template.

## Which Skill to Read Next

| Task | Read this skill next |
|---|---|
| Creating or editing any `.php` file | `skills/php-templating/SKILL.md` |
| Creating or editing any `.scss` file | `skills/scss-architecture/SKILL.md` |
| Running any build command | `skills/build-pipeline/SKILL.md` |
| Working with `uikit-manifest.json` | `skills/uikit-manifest/SKILL.md` |
| Working with `site-config.php` or data files | `skills/data-layer/SKILL.md` |
| Multi-theme or per-page theme setup | `skills/multi-theme/SKILL.md` |
| Checking or fixing `dist/` output | `skills/dist-output/SKILL.md` |
| Working on `style-guide.php` | `skills/style-guide/SKILL.md` |
| Scaffolding a new template project | `skills/template-scaffold/SKILL.md` |
| Deploying preview or packaging ZIP | `skills/preview-deploy/SKILL.md` |
| Something is broken or not working | `skills/debugging/SKILL.md` |

## SOP Reference

Full SOP lives in `squeditor-workspace/squeditor-framework-SOP.md`.
Always check the SOP section number referenced in the checklist before writing any file.