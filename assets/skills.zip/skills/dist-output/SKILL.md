---
name: dist-output
description: >
  Use this skill when checking whether the dist/ folder is correct, when assets like images
  or fonts are missing from the build output, when HTML files have broken links or wrong
  extensions, when the ZIP is missing files, or when verifying the build passed all checks.
  Covers the expected dist/ structure, how Vite copies static assets via publicDir, the
  .php to .html rewrite rules, the pre-zip sanity checks, and relative path requirements
  for offline HTML viewing.
---

# Dist Output Skill

## Expected `dist/` Structure After Full Build
dist/
├── index.html
├── about.html
├── services.html
├── contact.html
├── style-guide.html
├── 404.html
├── favicon.ico         ← copied from src/assets/static/ by Vite publicDir
└── assets/
    ├── images/             ← copied from src/assets/static/images/ by Vite publicDir
    ├── fonts/              ← copied from src/assets/static/fonts/ by Vite publicDir
    ├── css/
    │   ├── tailwind.css
    │   ├── uikit-components.css
    │   └── main.css
    └── js/
        ├── uikit-components.js
        └── main.js

## Static Asset Copy Rule

Vite copies `src/assets/static/` → `dist/` root verbatim via `publicDir` in `vite.config.js`.
Images go in `src/assets/static/images/` → land at `dist/images/`.
Fonts go in `src/assets/static/fonts/` → land at `dist/fonts/`.
Reference in PHP as `/images/logo.svg` — works in both dev (PHP server) and dist (flat HTML).

## .php → .html Rewrite Rules

`snapshot.js` rewrites: `href="about.php"` → `href="about.html"` in all crawled HTML.
This applies to `href` attributes only. Inline `src=` attributes using PHP are not rewritten
because assets use root-relative paths (`/images/...`), not `.php` references.

## Pre-ZIP Sanity Checks

Before calling `archive.finalize()`, verify these exist in `dist/`:
- `assets/css/tailwind.css`
- `assets/css/uikit-components.css`
- `assets/js/uikit-components.js`
- `assets/js/main.js`
- `images/` directory

Log a warning for any missing — do not abort the ZIP, just warn.

## Offline Viewing Requirement

All asset paths in HTML output must be root-relative (`/assets/css/tailwind.css`).
The ZIP is used by opening `index.html` directly in a browser — this means root-relative
paths will resolve correctly when opened via a local server but not by double-clicking.
Add a `README.html` to `dist/` with instructions: "Run a local server or upload to hosting."