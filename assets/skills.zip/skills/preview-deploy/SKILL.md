---
name: preview-deploy
description: >
  Use this skill when deploying a preview URL for a template project, when packaging the
  dist/ folder as a ZIP, when switching between Netlify and Vercel as the deploy target,
  or when the deploy step fails. Covers the CLI commands for each platform, the config flag
  that controls which platform is used, what a successful deploy confirmation looks like,
  and how to get a shareable URL.
---

# Preview Deploy Skill

## Platform Selection

Set in `squeditor.config.js`:
```js
dist: {
    zipName: 'my-project-dist.zip',
    previewPlatform: 'netlify',  // or 'vercel'
}
```

## Netlify Deploy
```bash
# package-dist.js runs this automatically
netlify deploy --dir=dist --open

# For production (permanent URL):
netlify deploy --dir=dist --prod
```

Success: Netlify prints a `Website Draft URL` — share this with the client.
If not logged in: `netlify login` first.

## Vercel Deploy
```bash
vercel dist --yes
```

Success: Vercel prints a deployment URL ending in `.vercel.app`.
If not logged in: `vercel login` first.

## ZIP Contents Verification

Before considering the deliverable complete, confirm the ZIP contains:
- All `.html` pages (no `.php` files)
- `assets/css/tailwind.css`
- `assets/css/uikit-components.css`
- `assets/css/main.css`
- `assets/js/uikit-components.js`
- `assets/js/main.js`
- `assets/images/` directory with all project images
- `assets/fonts/` directory if project uses custom fonts
- `favicon.ico`

## Three Deliverables Per Project

1. **Hosted preview URL** — from Netlify/Vercel deploy
2. **Downloadable ZIP** — `[project-name]-dist.zip` at template root
3. **Style guide URL** — hosted preview URL + `/style-guide.html`