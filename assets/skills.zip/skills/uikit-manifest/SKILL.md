---
name: uikit-manifest
description: >
  Use this skill when creating or updating squeditor/uikit-manifest.json, when adding a new
  UIKit3 component to the framework, or when a component's CSS or JS is missing from the
  compiled output. Covers how to inspect the UIKit3 npm package to find exact file paths,
  the manifest structure, the _core entry that must always be included first, what happens
  when a path is wrong, and how to verify component files exist before adding them.
---

# UIKit Manifest Skill

## Purpose

`squeditor/uikit-manifest.json` maps every UIKit3 component name to its exact CSS and JS
file paths within the UIKit3 npm package. `build-components.js` reads this to cherry-pick
only the components declared in `squeditor.config.js`.

## Before Writing the Manifest — Inspect First

UIKit3 file paths vary by version. ALWAYS inspect the installed package before writing paths:
```bash
# Run from inside any template folder that has UIKit installed
ls node_modules/uikit/dist/js/
ls node_modules/uikit/dist/css/
# Look for: uikit-core.js, and individual component files
```

Components may be in `dist/js/components/` or compiled into `uikit.js` depending on version.
Verify each file path EXISTS before adding it to the manifest.

## Manifest Structure
```json
{
  "_core": {
    "js":  ["node_modules/uikit/dist/js/uikit-core.js"],
    "css": ["node_modules/uikit/dist/css/uikit-core.min.css"]
  },
  "modal": {
    "js":  ["node_modules/uikit/dist/js/components/modal.js"],
    "css": ["node_modules/uikit/dist/css/components/modal.css"]
  }
}
```

Rules:
- `_core` is ALWAYS included first, automatically, regardless of `config.components`
- Component with no CSS (e.g. sticky, scrollspy) gets `"css": []` — empty array, not omitted
- Paths are relative to the template's `node_modules/` — resolved at build time from `projectRoot`
- If a CSS or JS file does not exist for a component, log a warning and skip — never throw

## 10 Standard Components

sticky, modal, accordion, tabs, offcanvas, dropdown, tooltip, scrollspy, parallax, slider

All 10 must be in the manifest. Components not in `config.components` are simply not included
in the output — the manifest entry still stays.

## Verification Step

After writing the manifest, add this check to the agent's task:
For each entry in the manifest, confirm `fs.existsSync(resolvedPath)` returns true.
If any path returns false, fix the path before proceeding to the build.