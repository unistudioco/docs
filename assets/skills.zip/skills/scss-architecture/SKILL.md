---
name: scss-architecture
description: >
  Use this skill whenever creating, editing, or debugging any .scss file in a Squeditor
  template project. Covers the strict 6-layer import order, what belongs in each layer,
  the CSS custom property naming convention (--sq-*), the themes/ subfolder pattern for
  multi-theme support, how the active theme import is auto-swapped by the build script,
  and what the _theme.scss layer is for. Read this before touching main.scss, _tokens.scss,
  _base.scss, _components.scss, _uikit-overrides.scss, _utilities.scss, _theme.scss,
  or any file in themes/.
---

# SCSS Architecture Skill

## Layer Order — NEVER reorder these imports
```scss
// main.scss — strict order, no exceptions
@import 'tokens';           // 1. CSS custom properties only
@import 'base';             // 2. Resets, body, typography
@import 'components';       // 3. Custom sq- component styles
@import 'uikit-overrides';  // 4. Override UIKit3 uk- styles
@import 'utilities';        // 5. Custom utility classes
// ↓ auto-replaced by build-components.js — DO NOT edit manually
@import 'themes/agency';    // 6. Active theme (highest specificity, always last)
```

## What Goes in Each Layer

| Layer | Allowed | Never put here |
|---|---|---|
| `_tokens.scss` | CSS custom properties (`--sq-*` vars) only | Any selectors or rules |
| `_base.scss` | `body`, `h1-h6`, `a`, `p`, resets | Component-specific styles |
| `_components.scss` | `.sq-card`, `.sq-hero`, `.sq--header` etc. | Tailwind utilities |
| `_uikit-overrides.scss` | `.uk-modal`, `.uk-accordion` overrides | New sq- classes |
| `_utilities.scss` | Helper classes not in Tailwind | Component structures |
| `_theme.scss` / `themes/_X.scss` | `:root` var overrides, project-specific rules | New component definitions |

## CSS Custom Property Naming

All framework tokens use `--sq-` prefix:
```scss
--sq-color-primary, --sq-color-secondary, --sq-font-sans, --sq-space-lg, --sq-radius-md
```
Never use `--ag-`, `--tw-`, or unprefixed vars for framework tokens.

## Theme Files (`themes/` subfolder)

Each theme file overrides ONLY `:root` custom properties from `_tokens.scss`:
```scss
// themes/_agency.scss — only :root overrides, nothing else
:root {
  --sq-color-primary:   #111827;
  --sq-color-secondary: #F59E0B;
  --sq-font-sans: 'Syne', sans-serif;
}
// Component scoping allowed here if essential:
.theme-agency .sq--header { background: var(--sq-color-primary); }
```

## Active Theme Auto-Swap Rule

`build-components.js` finds the last `@import 'themes/...'` line in `main.scss`
and replaces it with the theme matching `config.activeTheme`.
The comment `// auto-replaced by build-components.js` must remain on the line above
the theme import — the script uses it as an anchor to find the right line.

## Tailwind + SCSS Relationship

Tailwind outputs to `tailwind.css` — separate file, separate pipeline.
SCSS outputs are merged into the final stylesheet alongside `tailwind.css`.
Never `@import` Tailwind inside SCSS. Never use `@apply` — use utility classes in PHP directly.