---
name: php-templating
description: >
  Use this skill whenever writing, editing, or debugging any .php file in a Squeditor
  template project. Covers the WordPress-style helper functions (get_template_part,
  get_component, get_section), the output buffering pattern for page files, how base.php
  wires the layout together, frontmatter format and parsing, how $site data flows into
  templates, and the SRC_PATH constant. Read this before touching header.php, footer.php,
  nav.php, any page in pages/, any section variant, or base.php.
---

# PHP Templating Skill

## Four Core Helpers (defined in `squeditor/php/functions.php`)
```php
get_template_part('header');                          // → src/template-parts/header.php
get_template_part('nav', ['mobile' => true]);         // passes $args into partial

get_component('accordion', ['items' => $items]);      // → src/components/accordion.php
get_component('modal', ['demo' => true]);             // demo mode for style-guide

get_section('hero/hero-centered', ['heading' => '']); // → src/sections/hero/hero-centered.php

parse_frontmatter(__FILE__);                          // returns array from comment block
```

## Frontmatter Format (top of every page file)
```php
<?php
/*|
title: Page Title Here
description: Meta description for this page.
og_image: /images/og-page.jpg
|*/
```

The `|` delimiters are critical — parser uses `/*|` and `|*/` as boundaries.

## Page File Pattern (always use output buffering)
```php
<?php
/*| title: About | description: ... |*/

require_once __DIR__ . '/../data/team.php';   // load needed data

$page_title   = 'About Us';
$page_description = 'Our team...';
$body_class   = 'theme-agency page-about';    // always: theme-X page-Y

ob_start();
// ... all HTML output here using get_section(), get_component(), get_template_part()
$content = ob_get_clean();

require __DIR__ . '/../page-templates/base.php';  // always last line
```

## base.php Wiring Rules

- `base.php` is the ONLY file that outputs `<html>`, `<head>`, `<body>` tags
- It requires `functions.php` and `site-config.php` automatically
- It defines `SRC_PATH` as `__DIR__ . '/..` — all helpers resolve paths from this
- `$content` must be set before requiring `base.php` — it echoes it inside `<main>`
- CSS load order in `<head>`: `tailwind.css` → `uikit-components.css`
- JS load order before `</body>`: `uikit-components.js` → `main.js`

## $site Variable

`$site` is set in `src/config/site-config.php` and available in ALL templates automatically.
Access it as: `$site['name']`, `$site['nav']`, `$site['socials']`, `$site['contact']`.
Never re-require `site-config.php` inside partials — it is already loaded by `base.php`.

## Component Demo Mode

Every component in `src/components/` MUST support a `$demo` flag:
```php
// src/components/accordion.php
if (!empty($demo)) {
    // Use hardcoded sample content for style-guide rendering
    $items = [['title' => 'Sample Q', 'content' => 'Sample A']];
}
```

This is required for `style-guide.php` to render components without real data.

## SRC_PATH Constant

`SRC_PATH` is defined once in `base.php`. It equals the `src/` directory absolute path.
All helper functions build their file paths from `SRC_PATH`. Never redefine it.