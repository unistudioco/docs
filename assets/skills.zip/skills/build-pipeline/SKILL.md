---
name: build-pipeline
description: >
  Use this skill before running any build command in a Squeditor template project, or when
  debugging why a build step failed. Covers the full 3-stage build sequence (build:css →
  build:snap → build:zip), what each stage does and what its success output looks like,
  how build-components.js resolves paths via config.framework, the Vite build config,
  the active theme SCSS swap, and what to check when a stage fails. Read this before
  running npm run build, npm run build:css, npm run build:snap, or npm run build:zip.
---

# Build Pipeline Skill

## 3-Stage Build Sequence
npm run build
│
├── Stage 1: build:css
│     node ../squeditor/scripts/build-components.js   ← cherry-picks UIKit CSS+JS
│     vite build                                       ← compiles Tailwind + SCSS + main.js
│
├── Stage 2: build:snap
│     node ../squeditor/scripts/snapshot.js            ← crawls PHP server → flat HTML
│
└── Stage 3: build:zip
node ../squeditor/scripts/package-dist.js        ← zips dist/ + deploys preview

Run stages individually when debugging. Never skip stage order.

## Stage 1 — build-components.js

What it does:
1. Reads `squeditor.config.js` from `process.cwd()` (always run from template root)
2. Resolves `fwRoot` via `config.framework` (e.g. `../squeditor`)
3. Reads `fwRoot/uikit-manifest.json`
4. Concatenates UIKit `_core` CSS+JS first, then each selected component's CSS+JS
5. Writes `dist/assets/css/uikit-components.css` and `dist/assets/js/uikit-components.js`
6. Writes `src/config/active-components.php` for use by `style-guide.php`
7. Swaps the `@import 'themes/...'` line in `main.scss` to match `config.activeTheme`

Success output: `[Squeditor] ✅ uikit-components.css and uikit-components.js built successfully.`

## Stage 2 — snapshot.js

What it does:
1. Spawns PHP built-in server on `config.devServer.port` pointing at `src/`
2. Waits 1500ms for server to be ready (do NOT reduce this delay)
3. Fetches each page in `config.snapshot.pages` via HTTP GET
4. Rewrites `.php` hrefs to `.html` in the crawled HTML
5. Saves each page as an `.html` file in `config.snapshot.outputDir` (= `dist/`)
6. Kills PHP server process

Success output: `[Squeditor] 🏁 Snapshot complete.`

## Stage 3 — package-dist.js

What it does:
1. Checks `dist/assets/css`, `dist/assets/js`, `dist/images` exist — warns if missing
2. Creates ZIP archive of entire `dist/` folder
3. Deploys to Netlify or Vercel based on `config.dist.previewPlatform`

## Vite Build Output

Vite writes to `dist/assets/` (set by `build.outDir` in vite.config.js):
- `dist/assets/css/main.css` → renamed/referenced as `tailwind.css` after build
- `dist/assets/js/main.js` → project custom JS

Vite also copies everything from `src/assets/static/` → `dist/` root (via `publicDir`).
This is how images, fonts, and favicon land in `dist/`.

## Critical Path Rule

All scripts MUST be run from the template root (e.g. `cd showcase && npm run build`).
Never run build scripts from `squeditor/` — `process.cwd()` must equal the template folder.