---
name: data-layer
description: >
  Use this skill when creating or editing site-config.php, any data file in src/data/,
  or when data is not appearing correctly in templates. Covers the $site variable structure,
  how data flows from data files into PHP templates via require + loops, the frontmatter
  parser output format, and how to add new data types (services, portfolio, testimonials etc).
---

# Data Layer Skill

## Three Data Sources

1. **`src/config/site-config.php`** — global $site array, always available in all templates
2. **`src/data/*.php`** — loop data files, required per-page as needed
3. **Frontmatter** — per-page metadata, parsed by `parse_frontmatter()` for SEO tags

## $site Array Structure
```php
$site = [
    'name'        => 'Project Name',
    'lang'        => 'en',
    'logo'        => '/images/logo.svg',
    'description' => 'Default meta description.',
    'og_image'    => '/images/og-default.png',
    'url'         => 'https://example.com',
    'nav'         => [
        ['label' => 'Home', 'url' => '/'],
        ['label' => 'About', 'url' => '/about.html'],
    ],
    'socials'     => ['twitter' => '...', 'linkedin' => '...'],
    'contact'     => ['email' => '...', 'phone' => '...', 'address' => '...'],
];
```

`$site` is available in ALL template-parts and components automatically via base.php.
Never pass `$site` as an `$args` array — it is always in scope.

## Loop Data File Pattern
```php
// src/data/team.php
$team_members = [
    ['name' => 'Jane Doe', 'role' => 'Director', 'photo' => '/images/team/jane.jpg'],
];
```

To use in a page: `require_once __DIR__ . '/../data/team.php';` then `foreach ($team_members as $m)`.
Data files define ONLY arrays — no HTML output, no functions, no classes.

## Adding New Data Types

Follow the same pattern for: `services.php`, `portfolio.php`, `testimonials.php`, `pricing.php`.
Variable name = plural noun: `$services`, `$portfolio_items`, `$testimonials`, `$pricing_plans`.

## Frontmatter vs $site

Frontmatter = per-page overrides for title, description, og_image.
$site = global defaults used when frontmatter is absent.
base.php uses: `$page_title = $page_title ?? $site['name'];` — local var wins.