---
name: multi-theme
description: >
  Use this skill when setting up multiple themes or demo variants within a single template
  project, when configuring the themes{} block in squeditor.config.js, when the snapshot
  script needs to output to per-theme subfolders, when adding a ?theme= switcher to
  style-guide.php, or when body class scoping is needed for per-page theme styling.
  Also use when a project needs different visual identities for different page sets.
---

# Multi-Theme Skill

## Config Structure (`squeditor.config.js`)
```js
module.exports = {
  // ... other config ...
  activeTheme: 'agency',   // used during dev — sets which theme SCSS is imported
  themes: {
    'agency': {
      label:       'Agency Theme',
      bodyClass:   'theme-agency',
      scss:        'src/assets/scss/themes/_agency.scss',
      pages:       ['/', '/about.php', '/services.php'],
      distSubfolder: 'demo-agency',
    },
    'saas': {
      label:       'SaaS Theme',
      bodyClass:   'theme-saas',
      scss:        'src/assets/scss/themes/_saas.scss',
      pages:       ['/landing.php', '/pricing.php'],
      distSubfolder: 'demo-saas',
    },
  },
};
```

## dist/ Output Structure with Themes